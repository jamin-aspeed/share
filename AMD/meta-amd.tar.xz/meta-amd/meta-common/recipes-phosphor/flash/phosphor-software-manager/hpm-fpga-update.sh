#!/bin/bash
logger -t hpm-fpga-update "TODO: Update HPM FPGA update script as per the platform"
exit 0
