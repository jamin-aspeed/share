#!/bin/bash
logger -t bios-update "TODO: Update bios update script as per the platform"
exit 0
